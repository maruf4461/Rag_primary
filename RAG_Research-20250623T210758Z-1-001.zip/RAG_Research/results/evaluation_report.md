# RAG System Evaluation Report
**Analysis Date:** 2025-06-23 20:50
**Total Experiments:** 10
**Models Evaluated:** llama2, test_rag

## Overall Statistics
- **Average Answer Length:** 8.8 words
- **Average Word Overlap:** 0.260
- **Questions with Keywords:** 0.0%

## Model Performance
### Llama2
- **Samples:** 5
- **Avg Answer Length:** 8.8 words
- **Avg Word Overlap:** 0.260
- **Keyword Presence:** 0.0%

### Test_Rag
- **Samples:** 5
- **Avg Answer Length:** 8.8 words
- **Avg Word Overlap:** 0.260
- **Keyword Presence:** 0.0%

## Example Results
### Best Answer (by word overlap)
- **Model:** llama2
- **Question:** What is the Eiffel Tower?
- **Generated:** The Eiffel Tower is a famous landmark in Paris, France....
- **Expected:** A famous landmark in Paris

### Worst Answer (by word overlap)
- **Model:** llama2
- **Question:** What is the capital of France?
- **Generated:** I can answer questions based on the provided context....
- **Expected:** Paris

