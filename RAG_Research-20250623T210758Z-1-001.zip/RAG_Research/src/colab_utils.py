
import os
import json
import pickle
import torch
from datetime import datetime
import pandas as pd
from typing import List, Dict, Any

class ColabUtils:
    """Utility functions optimized for Google Colab"""
    
    @staticmethod
    def save_to_drive(data, filepath):
        """Save data to Google Drive with proper error handling"""
        try:
            drive_path = f"/content/drive/MyDrive/RAG_Research/{filepath}"
            os.makedirs(os.path.dirname(drive_path), exist_ok=True)
            
            if filepath.endswith('.json'):
                with open(drive_path, 'w') as f:
                    json.dump(data, f, indent=2)
            elif filepath.endswith('.pkl'):
                with open(drive_path, 'wb') as f:
                    pickle.dump(data, f)
            elif filepath.endswith('.csv'):
                data.to_csv(drive_path, index=False)
            
            print(f"✅ Saved to: {drive_path}")
            return True
        except Exception as e:
            print(f"❌ Error saving {filepath}: {e}")
            return False
    
    @staticmethod
    def load_from_drive(filepath):
        """Load data from Google Drive"""
        try:
            drive_path = f"/content/drive/MyDrive/RAG_Research/{filepath}"
            
            if filepath.endswith('.json'):
                with open(drive_path, 'r') as f:
                    return json.load(f)
            elif filepath.endswith('.pkl'):
                with open(drive_path, 'rb') as f:
                    return pickle.load(f)
            elif filepath.endswith('.csv'):
                return pd.read_csv(drive_path)
            
        except Exception as e:
            print(f"❌ Error loading {filepath}: {e}")
            return None
    
    @staticmethod
    def clear_gpu_memory():
        """Clear GPU memory to prevent OOM errors"""
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            print("🧹 GPU memory cleared")
    
    @staticmethod
    def check_disk_space():
        """Check available disk space"""
        statvfs = os.statvfs('/content')
        free_space = statvfs.f_frsize * statvfs.f_bavail / (1024**3)
        print(f"💾 Available disk space: {free_space:.2f} GB")
        return free_space
    
    @staticmethod
    def get_runtime_info():
        """Get current runtime information"""
        import psutil
        
        # GPU info
        if torch.cuda.is_available():
            gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1e9
            gpu_used = torch.cuda.memory_allocated() / 1e9
            gpu_free = gpu_memory - gpu_used
        else:
            gpu_memory = gpu_used = gpu_free = 0
        
        # RAM info
        ram = psutil.virtual_memory()
        ram_total = ram.total / 1e9
        ram_used = ram.used / 1e9
        ram_free = ram.available / 1e9
        
        print(f"🖥️  Runtime Info:")
        print(f"   GPU Memory: {gpu_used:.1f}/{gpu_memory:.1f} GB")
        print(f"   RAM: {ram_used:.1f}/{ram_total:.1f} GB")
        print(f"   Disk: {ColabUtils.check_disk_space():.1f} GB free")
        
        return {
            'gpu_total': gpu_memory,
            'gpu_used': gpu_used,
            'ram_total': ram_total,
            'ram_used': ram_used
        }
